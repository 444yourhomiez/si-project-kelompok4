<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('laporan_keuangan', function (Blueprint $table) {
            $table->id();
            $table->foreignId('manajemen_id')->constrained('manajemen')->onDelete('cascade');
            $table->foreignId('pengawas_id')->constrained('pengawas')->onDelete('cascade');
            $table->string('jenis');
            $table->date('periode_mulai');
            $table->date('periode_selesai');
            $table->decimal('total_simpanan', 15, 2);
            $table->decimal('total_pinjaman', 15, 2);
            $table->decimal('total_saldo', 15, 2);
            $table->string('file_path')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('laporan_keuangan');
    }
};
