<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cicilan', function (Blueprint $table) {
            $table->id();
            $table->foreignId('pinjaman_id')->constrained('pinjaman')->onDelete('cascade');
            $table->foreignId('manajemen_id')->constrained('manajemen')->onDelete('cascade');
            $table->integer('ke_cicilan');
            $table->decimal('nominal_cicilan', 15, 2);
            $table->decimal('nominal_bunga', 15, 2);
            $table->decimal('sisa_pokok', 15, 2);
            $table->date('tanggal_bayar');
            $table->date('tanggal_jatuh_tempo');
            $table->string('status')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cicilan');
    }
};
