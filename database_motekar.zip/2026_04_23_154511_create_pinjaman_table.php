<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('pinjaman', function (Blueprint $table) {
            $table->id();
            $table->foreignId('anggota_id')->constrained('anggota')->onDelete('cascade');
            $table->foreignId('manajemen_id')->constrained('manajemen')->onDelete('cascade');
            $table->string('no_pinjaman')->unique();
            $table->string('jenis');
            $table->decimal('jumlah_pinjaman', 15, 2);
            $table->decimal('bunga_persen', 15, 2);
            $table->integer('tenor_bulan');
            $table->decimal('angsuran_per_bulan', 15, 2);
            $table->date('tanggal_pengajuan');
            $table->date('tanggal_disetujui')->nullable();
            $table->string('status')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('pinjaman');
    }
};
